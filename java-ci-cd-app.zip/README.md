# Java CI/CD Project

CI/CD using GitHub Actions + Jenkins + Tomcat

Author: Sameer Abbas
